Acesta este Puffer Password Utility v1.3 - Un password manager complet offline -
Acest produs include:
-Generator de parole
-Stocare de parole
-Validator de parole

Adaugari in v1.3:
-acum generatorul nu mai da lungimi aleatorii de parola 
-acum utilitatea are dark mode


Pentru a folosi Puffer Password Utility v1.3:
-Muta shortcut-ul(patratul gri) in ce folder preferi
-Muta foldetul intitulat 'Puffer Password' in ce folder doresti
-Da dublu click pe shortcut

---Poti sterge acest fisier daca vrei---